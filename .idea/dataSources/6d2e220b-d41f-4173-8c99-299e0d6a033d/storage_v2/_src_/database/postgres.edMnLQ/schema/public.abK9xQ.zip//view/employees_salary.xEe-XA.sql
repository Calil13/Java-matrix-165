create view employees_salary(first_name, position, salary, company_name) as
SELECT e.first_name,
       e."position",
       e.salary,
       em.company_name
FROM employees e
         JOIN employers em ON e.employer_id = em.employers_id
WHERE e.salary > 3000::double precision;

alter table employees_salary
    owner to postgres;

